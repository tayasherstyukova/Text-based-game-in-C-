//CSCI1300 Fall 2021 Project 3
//Author: Taisiia Sherstiukova
//Recitation: 116 - Alexander Ray
//Date: December 2, 2021
#ifndef COMPUTER_H
#define COMPUTER_H
#include <iostream>
#include <string>
class Computer
{
    public:
    Computer();
    Computer(int maintenance, int viruses);
    int getMaintenanceLevel(); // returns computer's maintenance level
    void setMaintenanceLevel(int m); // sets computer's maintenance level to
    void modifyMaintenanceLevel(int num); // modifies computer's maintenance level to
    int getNumViruses(); // returns number of viruses
    void setNumViruses(int v); // sets number of viruses to
    void modifyNumViruses(int num); // modifies number of viruses
    private:
    int maintenance_level = 0;
    int num_viruses = 0;
};
#endif