//CSCI1300 Fall 2021 Project 3
//Author: Taisiia Sherstiukova
//Recitation: 116 - Alexander Ray
//Date: December 2, 2021
#include "Inventory.h"
#include <iostream>

using namespace std;

// default Constructor
Inventory::Inventory()
{
    num_cpu = 0;
    num_gpu = 0;
    num_power_supply_units = 0;
    num_computer_cases = 0;
    num_internet_cards = 0;
    num_keyboards_and_mouses = 0;
    num_premade_computers = 1;
    num_computer_parts = 0;
}
// parametrized Constructor
Inventory::Inventory(int cpu, int gpu, int power_supply_unit, int computer_case, int internet_card, int keyboard_and_mouse, int computer)
{
    num_cpu = cpu;
    num_gpu = gpu;
    num_power_supply_units = power_supply_unit;
    num_computer_cases = computer_case;
    num_internet_cards = internet_card;
    num_keyboards_and_mouses = keyboard_and_mouse;
    num_premade_computers = computer;
    num_computer_parts = cpu +gpu +power_supply_unit +computer_case +internet_card + keyboard_and_mouse;
}
// getters
int Inventory::getNumCpu()
{
    return num_cpu;
}
int Inventory::getNumGpu()
{
    return num_gpu;
}
int Inventory::getNumPowerSupplyUnits()
{
    return num_power_supply_units;
}
int Inventory::getNumComputerCases()
{
    return num_computer_cases;
}
int Inventory::getNumInternetCards()
{
    return num_internet_cards;
}
int Inventory::getNumKeyboardsAndMouses()
{
    return num_keyboards_and_mouses;
}
int Inventory::getNumPremadeComputers()
{
    return num_premade_computers;
}
int Inventory::getNumComputerParts()
{
    
    return num_computer_parts;
}

//setters
void Inventory::setNumCpu(int c)
{
    num_cpu = c;
}
void Inventory::setNumGpu(int g)
{
    num_gpu = g;
}
void Inventory::setNumPowerSupplyUnits(int p)
{
    num_power_supply_units = p;
}
void Inventory::setNumComputerCases(int cc)
{
    num_computer_cases = cc;
}
void Inventory::setNumInternetCards(int ic)
{
    num_internet_cards = ic;
}
void Inventory::setNumKeyboardsAndMouses(int km)
{
    num_keyboards_and_mouses = km;
}
void Inventory::setNumPremadeComputers(int pc)
{
    num_premade_computers = pc;
}
void Inventory::setNumComputerParts(int cp)
{
    num_computer_parts = cp;
}

//other 
void Inventory::modifyNumCpu(int num)
{
    num_cpu = num_cpu + num;
}
void Inventory::modifyNumGpu(int num)
{
    num_gpu = num_gpu + num;
}
void Inventory::modifyNumPowerSupplyUnits(int num)
{
    num_power_supply_units = num_power_supply_units + num;
}
void Inventory::modifyNumComputerCases(int num)
{
    num_computer_cases = num_computer_cases + num;
}
void Inventory::modifyNumInternetCards(int num)
{
    num_internet_cards = num_internet_cards + num;
}
void Inventory::modifyNumKeyboardsAndMouses(int num)
{
    num_keyboards_and_mouses = num_keyboards_and_mouses + num;
}
void Inventory::modifyNumPremadeComputers(int num)
{
    num_premade_computers = num_premade_computers + num;
}
void Inventory::modifyNumComputerParts(int num)
{
    num_computer_parts += num;
}
void Inventory::clearInventory()
{
    num_cpu =0;
    num_gpu =0;
    num_power_supply_units =0;
    num_computer_cases =0;
    num_internet_cards = 0;
    num_keyboards_and_mouses =0;
} 
void Inventory::displayInventory()
{
    cout << "INVENTORY: " << endl;
    cout << "1.CPU: " << num_cpu << endl;
    cout << "2.GPU: " << num_gpu << endl;
    cout << "3.Power Supply Unit: " << num_power_supply_units << endl;
    cout << "4.Computer Case: " << num_computer_cases << endl;
    cout << "5.Internet Card: " << num_internet_cards << endl;
    cout << "6.Keyboard and mouse: " << num_keyboards_and_mouses << endl;
    cout << "7.Quit" << endl; 
    // cout << "Enter the name of the computer part you would like to use: " << endl;
    
}