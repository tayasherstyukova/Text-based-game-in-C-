//CSCI1300 Fall 2021 Project 3
//Author: Taisiia Sherstiukova
//Recitation: 116 - Alexander Ray
//Date: December 2, 2021
#ifndef HACKER_H
#define HACKER_H

#include <iostream>
#include <string>

using namespace std;

class Hacker
{
    public:
    
    // default constructor
    Hacker();
    // parametrized constructor
    Hacker(string name, int room);
    // getters
    int getServerRoomNumber(); // returns the number of the server room
    string getHackerName(); // returns the name of the hacker
    int getNumHackersDefeated(); // returns the number of hackers defeated
    int getProgressCarmen(); // returns carmen's progress
    // setters
    void setServerRoomNumber(int number); // sets the number of the server room
    void setHackerName(string n); // sets the number of the hacker
    void setNumHackersDefeated(int num); // dets number of hackers defeated to
    void setProgressCarmen(int num); // sets carmen's progress to
    //other
    void displayHackerInfo(); // displays hacker's name and server room number
    void modifyNumHackersDefeated(int num); // modifies number of hacker defeated
    void modifyProgressCarmen(int num); // modifies carmen's progress
    private:
    string hacker_name = "";
    int server_room = 0;
    int num_hackers_defeated = 0;
    int progress_Carmen = 0;

};
#endif