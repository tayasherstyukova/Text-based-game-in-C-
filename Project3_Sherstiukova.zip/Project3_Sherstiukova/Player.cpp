//CSCI1300 Fall 2021 Project 3
//Author: Taisiia Sherstiukova
//Recitation: 116 - Alexander Ray
//Date: December 2, 2021
#include "Player.h"
#include <iostream>
#include <string>
#include <vector>
using namespace std;

Player::Player() // default constructor
{
    frustration_level = 0;
    num_dogecoins = 200;
    num_computers = 1;
    internet_provider_level = 1;
    num_vpn = 1;
}

// parametrized constructor
Player::Player(int frustration, int dogecoin, int computer, int internet_provider, int vpn)
{
frustration_level = frustration;
num_dogecoins = dogecoin;
num_computers = computer;
internet_provider_level = internet_provider;
num_vpn = vpn;
}

// getters
int Player::getFrustrationLevel()
{
    return frustration_level;
}
int Player::getDogecoinAmount()
{
    return num_dogecoins;
}
int Player::getComputerAmount()
{
    return num_computers;
}
int Player::getInternetProviderLevel()
{
    return internet_provider_level;
}
int Player::getVpnAmount()
{
    return num_vpn;
}

// setters
void Player::setFrustrationLevel(int f)
{
    frustration_level = f;
}
void Player::setDogecoinAmount(int d)
{
    num_dogecoins = d;
}
void Player::setComputerAmount(int c)
{
    num_computers = c;
}
void Player::setInternetProviderLevel(int i)
{
    internet_provider_level = i;
}
void Player::setVpnAmount(int v)
{
    num_vpn = v;
}
// other
void Player::display()
{
    cout << "Frustration level: " << frustration_level << endl;
    cout << "Dogecoins: " << num_dogecoins << endl;
    cout << "Computers: " << num_computers << endl;
    cout << "Internet providers: " << internet_provider_level << endl;
    cout << "VPN: " << num_vpn << endl;
} 

void Player::modifyFrustrationLevel(int x)
{
    frustration_level = frustration_level + x;
}
void Player::modifyDogecoinAmount(int y)
{
    num_dogecoins = num_dogecoins + y;
}
void Player::modifyComputerAmount(int z)
{
    num_computers = num_computers + z;
}
void Player::modifyInternetProviderLevel(int a)
{
    internet_provider_level = internet_provider_level + a;
}
void Player::modifyVpnAmount(int b)
{
    num_vpn = num_vpn + b;
}
