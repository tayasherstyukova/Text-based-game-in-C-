//CSCI1300 Fall 2021 Project 3
//Author: Taisiia Sherstiukova
//Recitation: 116 - Alexander Ray
//Date: December 2, 2021
#include "Hacker.h"
#include <iostream>
#include <string>
using namespace std;

// default constructor
    Hacker::Hacker()
    {  
        hacker_name = "";
        server_room = 0;
        
    }
    // parametrized constructor
    Hacker::Hacker(string name, int room)
    {
        hacker_name = name;
        server_room = room;
    }
    // getters
    int Hacker::getServerRoomNumber()
    {
        return server_room;
    }
    string Hacker::getHackerName()
    {
        return hacker_name;
    }
    int Hacker::getNumHackersDefeated()
    {
        return num_hackers_defeated;
    }
    int Hacker::getProgressCarmen()
    {
        return progress_Carmen;
    }
    // setters
    void Hacker::setServerRoomNumber(int number)
    {
        server_room = number;
    }
    void Hacker::setHackerName(string n)
    {
        hacker_name = n;
    }
    void Hacker::setNumHackersDefeated(int num)
    {
        num_hackers_defeated = num;
    }
    void Hacker::setProgressCarmen(int num)
    {
        progress_Carmen = num;
    }
    // other
    void Hacker::displayHackerInfo()
    {
        cout << "Name: " << hacker_name << endl;
        cout << "Server Room: " << server_room << endl;
        cout << "Number of hackers defeated: " << num_hackers_defeated << endl;
        cout << "Carmen's progress: " << progress_Carmen << endl;
    }
    void Hacker::modifyNumHackersDefeated(int num)
    {
        num_hackers_defeated += num;
    }
    void Hacker::modifyProgressCarmen(int num)
    {
        progress_Carmen +=num;
    }
    
