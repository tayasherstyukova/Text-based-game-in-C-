//CSCI1300 Fall 2021 Project 3
//Author: Taisiia Sherstiukova
//Recitation: 116 - Alexander Ray
//Date: December 2, 2021
#ifndef INVENTORY_H
#define INVENTORY_H
#include <iostream>

using namespace std;

class Inventory
{
    public:
    // default Constructor
    Inventory();
    // parametrized Constructor
    Inventory(int cpu, int gpu, int power_supply_unit, int computer_case, int internet_card, int keyboard_and_mouse, int computer);
    // getters
    int getNumCpu(); // returns the number of cpu
    int getNumGpu(); // returns the number of gpu
    int getNumPowerSupplyUnits(); // returns the number of power supply units
    int getNumComputerCases(); // returns the number of computer cases
    int getNumInternetCards(); // returns the number of internet cards
    int getNumKeyboardsAndMouses(); // returns the number of keyboards and mouses
    int getNumPremadeComputers(); // returns number of premade computers
    int getNumComputerParts(); // returns number of computer parts

    //setters
    void setNumCpu(int c); // sets the number of cpu
    void setNumGpu(int g); // sets the number of gpu
    void setNumPowerSupplyUnits(int p); // sets the number of power supply units
    void setNumComputerCases(int cc); // sets the number of computer cases
    void setNumInternetCards(int ic); // sets the number of internet cards
    void setNumKeyboardsAndMouses(int km); // sets the number of key oards and mouses
    void setNumPremadeComputers(int pc); // sets number of premade copmuters to
    void setNumComputerParts(int cp); // sets number of computer parts to

    //other 
    void modifyNumCpu(int num); // changes the number of cpu by
    void modifyNumGpu(int num); // changes the number of gpu by
    void modifyNumPowerSupplyUnits(int num); // changes the number of power supply units by
    void modifyNumComputerCases(int num); // changes the number of computer cases by
    void modifyNumInternetCards(int num); // changes the number of internet cards by
    void modifyNumKeyboardsAndMouses(int num); // changes the number of keyboards and mouses by
    void modifyNumPremadeComputers(int num); // modifies number of premade computers
    void modifyNumComputerParts(int num); // modifies number of computer parts
    
    void clearInventory(); // clears inventory

    void displayInventory(); // dsplays the inventory (cpu,gpu, power supply unit, computer case, internet cars, keyboard and mouse)

    private:
    int num_cpu = 0;
    int num_gpu = 0;
    int num_power_supply_units = 0;
    int num_computer_cases = 0;
    int num_internet_cards = 0;
    int num_keyboards_and_mouses = 0;
    int num_premade_computers = 0;
    int num_computer_parts = 0;
    
};
#endif