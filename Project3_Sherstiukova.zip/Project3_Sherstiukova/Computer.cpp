//CSCI1300 Fall 2021 Project 3
//Author: Taisiia Sherstiukova
//Recitation: 116 - Alexander Ray
//Date: December 2, 2021

#include "Computer.h"
#include <iostream>
#include <string>

using namespace std;

Computer::Computer()
{
    maintenance_level = 100;
    num_viruses = 0;
}
Computer::Computer(int maintenance, int viruses)
{
    maintenance_level = maintenance;
    num_viruses = viruses;
}
int Computer::getMaintenanceLevel()
{
    return maintenance_level;
}
void Computer::setMaintenanceLevel(int m)
{
    maintenance_level = m;
}      

void Computer::modifyMaintenanceLevel(int num)
{
    maintenance_level += num;
}
int Computer::getNumViruses()  
{
    return num_viruses;
}
void Computer::setNumViruses(int v)
{
    num_viruses = v;
}
void Computer::modifyNumViruses(int num)
{
    num_viruses += num;
}
