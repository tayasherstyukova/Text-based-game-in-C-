//CSCI1300 Fall 2021 Project 3
//Author: Taisiia Sherstiukova
//Recitation: 116 - Alexander Ray
//Date: December 2, 2021
#ifndef PLAYER_H
#define PLAYER_H

#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Player
{
    public:
    // vector <int> computer_parts = {0,0,0,0,0,0,0};
    int num_antivirus_USB = 0;
    int num_VPN = 0;
    int provider_level = 0;
    
    // default constructor
    Player();

    // parametrized constructor
    Player(int frustration, int dogecoin, int computer, int internet_provider, int vpn);

    // getters
    int getFrustrationLevel(); // returns the frustration level of the player
    int getDogecoinAmount(); // returns the number of dogecoins of the player
    int getComputerAmount(); // returns the number of computers of the player
    int getInternetProviderLevel(); // returns the number of internet providers of the player
    int getVpnAmount(); // returns the number of vpns of the player
    int getNumBestbuyVisit(); // returns the number of visits to bestbuy
    // setters
    void setFrustrationLevel(int f); // sets the frustration level to 
    void setDogecoinAmount(int d); // sets the number of dogecoins to
    void setComputerAmount(int c); // sets the number of computers to
    void setInternetProviderLevel(int i); // sets the number of internet providers to
    void setVpnAmount(int v); // sets the number of vpns to
    void setNumBesbuyVisit(int bb); // sets the number of bestbuy visit to
    // other
    void display(); // displays player's statisctics

    void modifyFrustrationLevel(int x); // changes the frustration level
    void modifyDogecoinAmount(int y); // changes the dogecoin amount
    void modifyComputerAmount(int z); // changes the number of computers
    void modifyInternetProviderLevel(int a); // changes the number of internet providers
    void modifyVpnAmount(int b); // changes the number of vpns
    void modifyNumBestbuyVisit(int num); // modifies the number of BB visits




    private:
    int frustration_level = 0;
    int num_dogecoins = 0;
    int num_computers = 0;
    int internet_provider_level = 0;
    int num_vpn = 0;
    int num_best_buy_visit = 0;
    
};
#endif