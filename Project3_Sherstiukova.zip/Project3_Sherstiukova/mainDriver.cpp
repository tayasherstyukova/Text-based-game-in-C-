// CSCI 1300 Fall 2021
// Author: Taisiia Sherstiukova
// Recitation: 116 - Alexander Ray
/*
Expected output:
Frustration level: 3
Dogecoins: 200
Computers: 1
Internet providers: 2
VPN: 5

3
200
1
2
5

Frustration level: 5
Dogecoins: 400
Computers: 2
Internet providers: 3
VPN: 2

Frustration level: 0
Dogecoins: 500
Computers: 4
Internet providers: 2
VPN: 7

INVENTORY: 
CPU: 2
GPU: 2
Power Supply Unit: 1
Computer Case: 1
Internet Card: 4
Keyboard and mouse: 2
Enter the name of the computer part you would like to use: 

Set number of CPUs to 6
Number of CPUs : 6

Increase number of computer cases by 4
Number of Computer Cases: 5

Decrease number of keyboards and mouses by 2
Number of Keyboards and Mouses: 0

INVENTORY: 
CPU: 6
GPU: 2
Power Supply Unit: 1
Computer Case: 5
Internet Card: 4
Keyboard and mouse: 0
Enter the name of the computer part you would like to use: 

hansolo1337
1
Name: gandalf5000
Server Room: 1 */


#include "Player.h"
#include "Inventory.h"
#include "Hacker.h"
#include "Game.h"
#include "Map.h"
#include <iostream>
#include <string>

using namespace std;
int main()
{
    // test cases for Player
    int frustration_level = 3;
    int num_dogecoins = 200;
    int num_computers = 1;
    int internet_provider_level = 2;
    int num_vpn = 5;
    Player player1 = Player(frustration_level, num_dogecoins, num_computers, internet_provider_level, num_vpn);

    player1.display();
    cout << endl;
    cout << player1.getFrustrationLevel() << endl;
    cout << player1.getDogecoinAmount() << endl;
    cout << player1.getComputerAmount() << endl;
    cout << player1.getInternetProviderAmount() << endl;
    cout << player1.getVpnAmount() << endl;
    cout << endl;

    player1.setFrustrationLevel(5);
    player1.setDogecoinAmount(400);
    player1.setComputerAmount(2);
    player1.setInternetProviderAmount(3);
    player1.setVpnAmount(2);
    player1.display();
    cout << endl;

    player1.modifyFrustrationLevel(-5);
    player1.modifyDogecoinAmount(100);
    player1.modifyComputerAmount(2);
    player1.modifyInternetProviderAmount(-1);
    player1.modifyVpnAmount(5);
    player1.display();
    cout << endl;
    // test cases for Inventory
    int num_cpu = 2;
    int num_gpu = 2;
    int num_power_supply_units = 1;
    int num_computer_cases = 1;
    int num_internet_cards = 4;
    int num_keyboards_and_mouses = 2;
    Inventory inventory1 = Inventory(num_cpu, num_gpu, num_power_supply_units, num_computer_cases, num_internet_cards, num_keyboards_and_mouses);

    inventory1.displayInventory();
    cout << endl;

    cout << "Set number of CPUs to 6" << endl;
    inventory1.setNumCpu(6);
    cout << "Number of CPUs : " <<inventory1.getNumCpu() << endl;
    cout << endl;

    cout << "Increase number of computer cases by 4" << endl;
    inventory1.modifyNumComputerCases(4);
    cout << "Number of Computer Cases: " << inventory1.getNumComputerCases() << endl;
    cout << endl;

    cout << "Decrease number of keyboards and mouses by 2" << endl;
    inventory1.modifyNumKeyboardsAndMouses(-2);
    cout << "Number of Keyboards and Mouses: " << inventory1.getNumKeyboardsAndMouses() << endl;
    cout << endl;

    inventory1.displayInventory();
    cout << endl;

    // test cases for Hacker
    string name = "hansolo1337";
    int room = 1;
    Hacker hacker1(name,room);
    cout << hacker1.getHackerName()<< endl;;
    cout << hacker1.getServerRoomNumber()<< endl;

    Hacker hacker2;
    hacker2.setHackerName("gandalf5000");
    hacker2.setServerRoomNumber(1);
    hacker2.displayHackerInfo();

    
}