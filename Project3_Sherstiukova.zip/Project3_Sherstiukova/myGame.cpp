//CSCI1300 Fall 2021 Project 3
//Author: Taisiia Sherstiukova
//Recitation: 116 - Alexander Ray
//Date: December 2, 2021
#include "Player.h"
#include "Hacker.h"
#include "Computer.h"
#include "Map.h"
#include "time.h"
#include "Inventory.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;
int split(string str, char delimiter, string array[], int size)

{
    int num = 0; // number of pieces of strings
    string s = "";// to store future pieces of string
    int len=str.length();

    if (len == 0)
    {
        return 0;
    }
    else
    {
        for (int i=0; i<len; i++) // iterates through the string
        {
            if (str[i]==delimiter) // checks if the character is a delimiter
            {
                
                if(len != 0) // checks if the string s is not empty
                    {
                        array[num] = s; 
                        num++;
                        s = ""; // clears the string s
                    }
                
            }
            else
            {
                s = s+str[i]; // adding a character that is not a delimiter
            }
            array[num] = s; // for the last piece of string

        }
        num++;
        if (num > size)
        {
            return -1;
        }
        else
        { 
        return num;
        }
    }
}
void loseRandomComputerPart(Inventory&inventory1)
{
    srand(time(0));
    int num = rand()%6+1;
    if (inventory1.getNumComputerParts() >=1)
    {
        if(num == 1 && inventory1.getNumCpu() >=1) // losing CPUs
        {
            inventory1.modifyNumCpu(-1);
            inventory1.modifyNumComputerParts(-1);
            // break;
        }
        if(num == 2 && inventory1.getNumGpu() >=1) // losing GPUs
        {
           inventory1.modifyNumGpu(-1);
           inventory1.modifyNumComputerParts(-1);
        //    break;
        }
        if(num == 3 && inventory1.getNumPowerSupplyUnits() >=1) // losing Power Supply Units
        {
            inventory1.modifyNumPowerSupplyUnits(-1);
            inventory1.modifyNumComputerParts(-1);
            // break;
        }
        if(num == 4 && inventory1.getNumComputerCases() >=1) // losing Computer Cases
        {
            inventory1.modifyNumComputerCases((-1));
            inventory1.modifyNumComputerParts(-1);
            // break;
        }
        if(num == 5 && inventory1.getNumInternetCards() >=1) // losing Internet Cards
        {
            inventory1.modifyNumInternetCards(-1);
            inventory1.modifyNumComputerParts(-1);
            // break;
        }
        if(num ==6 && inventory1.getNumKeyboardsAndMouses()) // losing keyboards and mouses
        {
            inventory1.modifyNumKeyboardsAndMouses(-1);
            inventory1.modifyNumComputerParts(-1);
            // break;
        }
    }
    else
    {
        cout << "You do not have any computer parts to lose" << endl;
        cout << endl;
    }

}
void gainRandomComputerPart(Inventory&inventory1)
{
    srand(time(0));
    int num = rand()%6+1;
    if(num == 1) // gaining CPU
    {
        inventory1.modifyNumCpu(1);
        inventory1.modifyNumComputerParts(1);
    }
    else if (num == 2) // gaining GPU
    {
        inventory1.modifyNumGpu(1);
        inventory1.modifyNumComputerParts(1);
    }
    else if(num == 3) // gaining power supply units
    {
        inventory1.modifyNumPowerSupplyUnits(1);
        inventory1.modifyNumComputerParts(1);
    }
    else if(num == 4) // gaining computer cases
    {
        inventory1.modifyNumComputerCases(1);
        inventory1.modifyNumComputerParts(1);
    }
    else if(num == 5) // gaining internet cards
    {
        inventory1.modifyNumInternetCards(1);
        inventory1.modifyNumComputerParts(1);
    }
    else if (num ==6) // gaining keyboards and mouses
    {
        inventory1.modifyNumKeyboardsAndMouses(1);
        inventory1.modifyNumComputerParts(1);
    }
}
void StatusUpdate(Computer&computer1, Player&player1, Inventory&inventory1, Hacker&hacker1)

{
    cout << "The computer's current maintenance level: " << computer1.getMaintenanceLevel() << endl;
    cout << "Number of viruses the computer has: " << computer1.getNumViruses() << endl;
    cout << "Computer parts available: " << inventory1.getNumComputerParts() << endl;
    cout << "CPU: " << inventory1.getNumCpu() << endl;
    cout << "GPU: " << inventory1.getNumGpu() << endl;
    cout << "Power Supply Unit: " << inventory1.getNumPowerSupplyUnits() << endl;
    cout << "Computer Case: " << inventory1.getNumComputerCases() << endl;
    cout << "Internet Card: " << inventory1.getNumInternetCards() << endl;
    cout << "Keyboard and mouse: " << inventory1.getNumKeyboardsAndMouses() << endl;
    cout << "Premade Computers: " << inventory1.getNumPremadeComputers() << endl;
    cout << "Antivirus USB sticks available: " << player1.num_antivirus_USB << endl;
    cout << "VPNs available: " << player1.getVpnAmount() << endl;
    cout << "Internet provider level: " << player1.getInternetProviderLevel() << endl;
    cout << "Amount of Dogecoin left: " << player1.getDogecoinAmount() << endl;
    cout << "Your frustration level: " << player1.getFrustrationLevel() << endl;
    cout << "Carmen's progress: " << hacker1.getProgressCarmen() << endl;
    cout << "Number of hackers defeated: " << hacker1.getNumHackersDefeated() << endl;

}
void activityMenu()
{
    cout << "1. Fight a Hacker" << endl;
    cout << "2. Speak to NPC(non-player character)" << endl;
    cout << "3. Repair your computer" << endl;
    cout << "4. Use your Antivirus Software" << endl;
    cout << "5. Travel the Server Room" << endl;
    cout << "6. Browse StackOverflow" << endl;
    cout << "7. Visit Bestbuy" << endl;
    cout << "8. Quit the Game" << endl;
}
void InventoryMenu()
{
    cout << "====Menu====" << endl;
    cout << "1. CPU (10 Dogecoins)" << endl;
    cout << "2. GPU (20 Dogecoins)" << endl;
    cout << "3. Power Supply Unit (5 Dogecoins)" << endl;
    cout << "4. Computer Case (15 Dogecoins)" << endl;
    cout << "5. Internet card (5 Dogecoins)" << endl;
    cout << "6. Keyboard and mouse (10 Dogecoins)" << endl;
    cout << "7. Premade computer (100 Dogecoins)" << endl;
    cout << "8. Quit(not buying any computer parts)" << endl;
}
void computerParts(Player&player1, Inventory&inventory1, int&total_cost, int&room_number)
{
    cout << "Choosing computer parts:" << endl;
    double price_coefficient = 0;
    // using price coefficients to update prices sinces prices in rooms increse as the user progresses
    if(room_number == 1)
    {
        price_coefficient =1;
    }
    else if(room_number == 2)
    {
        price_coefficient =1.1;
    }
    else if(room_number == 3)
    {
        price_coefficient = 1.2;
    }
    else if(room_number == 4)
    {
        price_coefficient = 1.25;
    }
    else if(room_number == 5)
    {
        price_coefficient = 1.3;
    }
    int x2 = 0;
    double price_cpu = price_coefficient *10;
    double price_gpu = price_coefficient * 20;
    double price_power_supply_unit = price_coefficient * 5;
    double price_computer_case = price_coefficient * 15;
    double price_internet_card = price_coefficient * 5;
    double price_keyboard_and_mouse = price_coefficient * 10;
    double price_premade_computer = price_coefficient * 100;
    do
    {
        InventoryMenu();
        cin >> x2;
        
        
        switch (x2)
        {
        case 1: // choosing CPU
            {
                int a = 0;
                cout << "How many CPUs do you wish to purchase?" << endl;
                cin.ignore();
                cin >> a;
                if(inventory1.getNumCpu() + a <= 3) // checking if the number of CPUs in the inventory is not greater than 3
                {
                    if(player1.getDogecoinAmount() >= price_cpu * a) // checking if the user has enough money
                    {
                        inventory1.modifyNumCpu(a); // increases the number of CPUs
                        inventory1.modifyNumComputerParts(1);
                        player1.modifyDogecoinAmount(-1*price_cpu*a); // modifies user balance
                        
                        total_cost += price_cpu *a; // modifies total cost
                        cout << "Total cost so far: " << total_cost << endl;
                    }
                    else
                    {
                        cout << "You don't have enough Dogecoins. Try a different quantity or item." << endl;
                    }
                }
                else 
                {
                    cout << "You cannot have more than 3 CPUs." << endl;
                }
                cin.clear();
                break;
            }
        case 2: // buying GPU
            {
                int b =0;
                cout << "How many GPUs do you wish to purchase?" << endl;
                cin.ignore();
                cin >> b;
                if(inventory1.getNumGpu() + b <= 3) // checking if the number of GPUs in the inventory is no greater than 3
                {
                    if(player1.getDogecoinAmount() >= price_gpu * b) // checking if the user has enough money
                    {
                        inventory1.modifyNumComputerParts(1);
                        inventory1.modifyNumGpu(b); // increasing GPU amount
                        player1.modifyDogecoinAmount(-1*price_gpu*b); // modifies user balance
                        total_cost += price_gpu*b; // modifies total cost
                        cout << "Total cost so far: " << total_cost << endl;
                    }
                    else
                    {
                        cout << "You don't have enough Dogecoins. Try a different quantity or item." << endl;
                    }
                }
                
                else
                {
                    cout << "You cannot have more than 3 GPUs." << endl;
                }
                cin.clear();
                break;
            }
        case 3: // buying power supply units
        {
            int c =0;
            cout << "How many Power Supply Units do you wish to purchase?" << endl;
            cin.ignore();
            cin >> c;
            if(inventory1.getNumPowerSupplyUnits() + c <= 3) // checking if the number psu does not exceed 3 in the inventory
            {
                if(player1.getDogecoinAmount() >= price_power_supply_unit *c) // checking if the user has enough money
                {
                    inventory1.modifyNumComputerParts(1);
                    inventory1.modifyNumPowerSupplyUnits(c); // modifies num of psu in the inventory
                    player1.modifyDogecoinAmount(-1*price_power_supply_unit*c); // modifies user balance
                    total_cost += price_power_supply_unit*c; // modifies total cost
                    cout << "Total cost so far: " << total_cost << endl;
                }
                else
                {
                    cout << "You don't have enough Dogecoins. Try a different quantity or item." << endl;
                }
            }
            else
            {
                cout << "You cannot have more than 3 Power Supply Units." << endl;
            }
            break;
        }
        case 4: // buying computer cases
        {
            int d =0;
            cout << "How many Computer Cases do you wish to purchase?" << endl;
            cin.ignore();
            cin >> d;
            if(inventory1.getNumComputerCases() + d <= 3) // checking if the num of cc in the inventory does not exceed 3
            {
                if(player1.getDogecoinAmount() >= price_computer_case*d) // checking if the user has enough money
                {
                    inventory1.modifyNumComputerParts(1);
                    inventory1.modifyNumComputerCases(d); // modifying num of cc in the inventory
                    player1.modifyDogecoinAmount(-1*price_computer_case*d); // modifying user balance
                    total_cost += price_computer_case*d; // modifying total cost
                    cout << "Total cost so far: " << total_cost << endl;
                }
                else
                {
                    cout << "You don't have enough Dogecoins. Try a different quantity or item." << endl;
                }
            }
            else
            {
                cout << "You cannot have more than 3 Computer Cases." << endl;
            }
            break;
        }

        case 5: // buying internet cards
        {
            int e =0;
            cout << "How many Internet Cards do you wish to purchase?" << endl;
            cin.ignore();
            cin >> e;
            if(inventory1.getNumInternetCards() + e <= 3) // checking if the num of cc in the inventory does not exceed 3
            {
                
                if(player1.getDogecoinAmount() >= price_internet_card*e) // checking if the user has enough money
                {
                    inventory1.modifyNumComputerParts(1);
                    inventory1.modifyNumInternetCards(e); // modifying the num of cc in the inventory
                    player1.modifyDogecoinAmount(-1*price_internet_card*e); // modifying user balance
                    total_cost += price_internet_card*e; // modifying total cost
                    cout << "Total cost so far: " << total_cost << endl;
                }
                else
                {
                    cout << "You don't have enough Dogecoins. Try a different quantity or item." << endl;
                }
            }
            else
            {
                cout << "You cannot have more than 3 Internet Cards." << endl;
            }
            break;
        }
        case 6: // buying keyboards and mouses
        {
            int f=0;
            cout << "How many keyboards and mouses do you wish to purchase?" << endl;
            cin.ignore();
            cin >> f;
            if(inventory1.getNumKeyboardsAndMouses() + f <= 3) // checking if the num k&m does not exceed 3 in the inventory
            {
                if(player1.getDogecoinAmount() >=price_keyboard_and_mouse*f) // checking if the user has enough money
                {
                    inventory1.modifyNumComputerParts(1);
                    inventory1.modifyNumKeyboardsAndMouses(f); // modifying the num of k&m in the inventory
                    player1.modifyDogecoinAmount(-1*price_keyboard_and_mouse*f); // modifying user balance
                    total_cost += price_keyboard_and_mouse*f; // modifying total cost
                    cout << "Total cost so far: " << total_cost << endl;
                }
                else
                {
                    cout << "You don't have enough Dogecoins. Try a different quantity or item." << endl;
                }
            }
            else
            {
                cout << "You cannot have more than 3 keyboards and mouses." << endl;
            }
            break;
        }
        case 7: // buying premade computers
        {
            int g = 0;
            cout << "How many premade computers do you wish to purchase?" << endl;
            cin.ignore();
            cin >> g;
            if(inventory1.getNumPremadeComputers() + g <= 2) // checking if the user has no more than 1 extra premade computer
            {
                if(player1.getDogecoinAmount() >=price_premade_computer*g) // checking f the user has enough money
                {
                    inventory1.modifyNumComputerParts(1);
                    inventory1.modifyNumPremadeComputers(g); //modifying the num of pc in the inventory
                    player1.modifyDogecoinAmount(-1*price_premade_computer*g); // modifying user balance
                    total_cost += price_premade_computer*g; // modifying total cost
                    cout << "Total cost so far: " << total_cost << endl;
                }
                else
                {
                    cout << "You don't have enough Dogecoins. Try a different quantity or item." << endl;
                }
            }
            else
            {
                cout << "You cannot have more than 1 extra premade computer." << endl;
            }
            break;
        }
        
        case 8: // quiting
        {
            return;
        }
        default: // incorrect input
        {
            cout << "Your input was incorrect. Input an integer value 1-8." << endl;
            break;
        }
        }

        
    } while(x2 != 8);

}
void useAntivirus(Player&player1,Computer&computer1)
{
    if(computer1.getNumViruses() > 0)
    {
        if(player1.num_antivirus_USB > 0)
        {
            computer1.setNumViruses(0);
            player1.num_antivirus_USB -= 1;
        }
        cout << "Your computer is cleared from viruses" << endl;
    }
    else
    {
        cout << "Your computer is not infected. You do not need any antivirus software." << endl;
    }
}
void readHackers(Player&player1, Hacker&hacker1, vector<Hacker>&hackers)
{

    

    string line = "";
    int split_value = 0;
    string array[2];
    
    ifstream inFile;
    inFile.open("hackers.txt");
    if(inFile.is_open())
    {
        while(getline(inFile,line))
        {
            if(line.length() >=1)
            {
                split_value = split(line, ',',array, 2);
                string name = array[0];
                int room = stoi(array[1]);
                Hacker new_hacker(name, room);
                hackers.push_back(new_hacker);
                
                
            }
            else
            {
                continue;
            }
        }
    }
        inFile.close();
}   
void fightHacker(Player&player1, Computer&computer1, Inventory&inventory1, Hacker&hacker1, Map&map1, int&room_number,vector <Hacker>&hackers, int&num_hackers, vector<string>&hacker_names)
{
    Hacker hacker = Hacker();
    int number = 0;
    string name  = "";
    if(map1.isHackerLocation()) // checking if the player is located in a space with a hacker
    {
        for (int i=0; i < hackers.size(); i++)
        {
            if(hackers[i].getServerRoomNumber() == room_number)
            {
                hacker.setHackerName(hackers[i].getHackerName());
                number =i;
                break;
            }
        }
        StatusUpdate(computer1, player1, inventory1, hacker1);
        cout << endl;
        cout << "You just ran into " << hacker.getHackerName() << " . Think you can beat this hacker's skills?" << endl;
        int option = 0;
        cout << "Choose one of the 2 options" << endl;
        cout << "1. Attack" << endl;
        cout << "2. Forfeit" << endl;
        cin.ignore();
        cin >> option;
        srand(time(NULL));
        switch(option)
        {
            case 1: // attack
            {
                if(computer1.getMaintenanceLevel() > 0)
                {
                    int r1 = rand()%6 +1;
                    int r2 = rand()%6 +1;
                    int battle_result = (player1.getInternetProviderLevel() * r1) - (r2*room_number * (1/player1.getVpnAmount()));
                    if(battle_result > 0) // winning
                    {
                        cout << "Congrats! You won the hacker!" << endl;
                        cout << endl;
                        hacker1.modifyNumHackersDefeated(1);
                        cout << "Current number of hackers defeated in the room is: " << hacker1.getNumHackersDefeated() << endl;
                        player1.modifyDogecoinAmount(50);
                        name = hackers[number].getHackerName();
                        hacker_names.push_back(name);
                        // setting room number to invalid so that the player doesn't fight the same hacker again
                        hackers.at(number).setServerRoomNumber(-1);
                        // erasing the hacker from map
                        map1.eraseHacker(map1, num_hackers);
                        number = 0;
                        
                        
                    }
                    else //losing
                    {
                        cout << "You lost the battle. Maybe you'll have better luck next time ;)" << endl;
                        cout << endl;
                        computer1.modifyMaintenanceLevel(-20); // maintenance level drops by 20
                        // 10% chance of being infected by a virus
                        if(rand() % 100 < 10)
                        {
                            cout << "Oh no! You've been infected by a virus!" << endl;
                            cout << endl;
                            computer1.modifyNumViruses(1);
                        }
                        hacker1.modifyProgressCarmen(25); // Carmen's progress increases by 25 
                    }
                }
                else
                {
                    cout << "Your maintenance level is less than or equal to 0. You cannot attack." << endl;
                    cout << endl;
                }
                
                
                break;
            }

            case 2: // forfeit
            {
                cout << "You were unable to win Carmen's hacker. Be better prepared next time!" << endl;
                cout << endl;
                inventory1.clearInventory();
                break;
            }
        }
        // 30% chance of maintenance level to drop by 10% unless final battle
        if((rand()%100 < 30) && (hacker1.getServerRoomNumber() != 5 && num_hackers - hacker1.getNumHackersDefeated() == 1))
        {
            computer1.modifyMaintenanceLevel(-10);
            cout << "You are unlucky this time. Your maintenance level has been dropped by 10." << endl;
            cout << endl;
        }
        // no matter what the outcome loses computer part
        loseRandomComputerPart(inventory1);
        
}
    else
    {
        cout << "You are not in the space with a hacker. You cannot fight the hacker." << endl;
        cout << endl;
    }
}
void misfortune(Inventory&inventory1, Computer&computer1)
{
    srand(time(NULL));
    // 30% chance of misfortune
    if(rand()%100 < 30)
    {
        if(inventory1.getNumComputerParts() >=1)
        {
            cout << "Oh no! You have encountered a misfortune. You are losing a random computer part!" << endl;
            cout << endl;
            // loses a random computer part
            loseRandomComputerPart(inventory1);
        }
        else
        {
            cout << "Oh no! You have encountered a misfortune. Your computer's maintenance level has been dropped by 10!" << endl;
            cout << endl;
            // maintenance level decreases by 10
            computer1.modifyMaintenanceLevel(-10);
        }
    }   
}
bool rockPaperScissors()
{
    bool result;
    char rock;
    char paper;
    char scissors;
    char computer_choice;
    // computer's move
    srand(time(NULL));
    int number = rand()%3 +1;
    if(number ==1)
    {
        computer_choice = 'r';
    }
    if(number == 2)
    {
        computer_choice= 'p';
    }
    if(number == 3)
    {
        computer_choice = 's';
    }
    // your move
    char your_choice;
    cout << "You are playing Rock, Paper, Scissors Game!" << endl;
    cout << "Choose an option: " << endl;
    cout << "r - for rock " << "p - for paper" << "s - for scissors" << endl;
    cin >> your_choice;

    if(your_choice == 's' && computer_choice == 'p')
    {
        cout << "You won. Scissors cut paper!" << endl;
        cout << endl;
        result = true;
    }
    else if (your_choice == 'p' && computer_choice == 's')
    {
        cout << "Computer won. Scissors cut paper!" << endl;
        cout << endl;
        result = false;
    }
    else if(your_choice == 'p' && computer_choice == 'r')
    {
        cout << "You won. Paper wraps rock!" << endl;
        cout << endl;
        result = true;
    }
    else if(computer_choice == 'p' && your_choice == 'r')
    {
        cout << "Computer won. Paper wraps rock!" << endl;
        cout << endl;
        result = false;
    }
    else if(your_choice == 'r' && computer_choice == 's')
    {
        cout << "You won. Rock crashes scissors!" << endl;
        cout << endl;
        result = true;
    }
    else if(your_choice == 's' && computer_choice == 'r')
    {
        cout << "Computer won. Rock crashes scissors!" << endl; 
        cout << endl;
        result =  false;
    }
    else
    {
        cout << "It's a tie. Play again." << endl;
        cout << endl;
        result = false;
    }
    return result;
}
void travelRoom(Player&player1, Inventory&inventory1, Map&map1, Computer&computer1, Hacker&hacker1)
{

    char move;  // for storing user input
    // quit after 10 moves
    for(int i = 0; i < 10; i++) 
    {
        map1.displayMap();  // print map in the terminal

        cout << "Valid moves are: " << endl; 
        map1.displayMoves();  // give user a menu of valid moves to pick from
        cout << "q (Quit) " << endl; // quit if the user wants to finish before they reach 10 moves
        cout << "Input a move: "; 
        cin >> move;
        cout << endl;
        if(move == 'q')
        {
            break;
        }
        map1.executeMove(move);  // move the player on map based on user input

        if (map1.isBestBuyLocation()) {
            cout << "You're in a Best Buy!" << endl;
        }

        if (map1.isHackerLocation()) {
            cout << "You've encountered a Hacker!" << endl;
        }

        if (map1.isNPCLocation()) {
            cout << "You've encountered an NPC!" << endl;
        }
        misfortune(inventory1, computer1); // 30% chance of misfortune
    }
}
void repair(int num_parts, Computer&computer1)
{
    if (num_parts == 1)
    {
        cout << "Your computer was repaired. Maintenance level up by 20." << endl;
        computer1.modifyMaintenanceLevel(20);
    }
    else if(num_parts == 2)
    {
        cout << "Your computer was repaired. Maintenance level up by 40." << endl;
        computer1.modifyMaintenanceLevel(40);
    }
    else if(num_parts == 3)
    {
        cout << "Your computer was repaired. Maintenance level up by 60." << endl;
        computer1.modifyMaintenanceLevel(60);
    }
    else if(num_parts == 4)
    {
        cout << "Your computer was repaired. Maintenance level up by 80." << endl;
        computer1.modifyMaintenanceLevel(80);
    }
    else if (num_parts == 5)
    {
        cout << "Your computer was repaired. Maintenance level up by 100." << endl;
        computer1.modifyMaintenanceLevel(100);
    }
        
}
void repairComputer(Computer&computer1, Inventory&inventory1, Player&player1)
{
    if(computer1.getNumViruses() >= 1) // you cannot repair the computer if it has viruses
    {
        cout << "Your computer is infected by viruses. You cannot repair it." << endl;
    }
    else
    {
        if(computer1.getMaintenanceLevel() < 100)
        {
            inventory1.displayInventory();
            int number = 0;
            cout << "Enter the number of the computer part you would like to use: " << endl;
            cin >> number;
            int num_parts = 0;
            do
            {
                switch(number)
                {
                    case 1:
                    {
                        int x1 = 0;
                        
                        cout << "Enter the quantity of CPUs you would like to use: (up to 5) " << endl;
                        cin >> x1;
                        if(x1 > 5)
                        {
                            cout << "You cannot choose more than 5 parts. Try again: " << endl;
                            cin >> x1;
                        }
                        if(x1 <= inventory1.getNumCpu())
                        {
                            inventory1.modifyNumCpu(-x1);
                            inventory1.modifyNumComputerParts(-x1);
                            num_parts +=x1; 
                            repair(num_parts, computer1);
                            return;
                        }
                        else 
                        {
                            cout << "You do not have enough CPUs. Try again." << endl;
                            break;
                        }
                        
                        break;
                    }

                    case 2:
                    {
                        int x2 = 0;
                        cout << "Enter the quantity of GPUs you would like to use:  (up to 5)" << endl;
                        cin >> x2;
                        if(x2 > 5)
                        {
                            cout << "You cannot choose more than 5. Try again: " << endl;
                        }
                        if(inventory1.getNumGpu() >= x2)
                        {
                            inventory1.modifyNumGpu(-x2);
                            inventory1.modifyNumComputerParts(-x2);
                            num_parts +=x2;
                            repair(num_parts,computer1);
                            return;
                        }
                        else
                        {
                            cout << "You do not have enough GPUs. Try again." << endl;
                            break;
                        }
                        break;
                    }
                    
                    case 3:
                    {
                        int x3 = 0;
                        cout << "Enter the quantity of Power Supply Units you would like to use: (up to 5)" << endl;
                        cin >> x3;
                        if(x3 > 5)
                        {
                            cout << "You cannot choose more than 5. Try again: " << endl;
                            cin >> x3;
                        }
                        if(inventory1.getNumPowerSupplyUnits() >= x3)
                        {
                            inventory1.modifyNumPowerSupplyUnits(-x3);
                            inventory1.modifyNumComputerParts(-x3);
                            num_parts +=x3;
                            repair(num_parts, computer1);
                            return;
                        }
                        else
                        {
                            cout << "You do not have enough power supply units. Try again: " << endl;
                            break;
                        }
                        break;
                    }

                    case 4:
                    {
                        int x4 = 0;
                        cout << "Enter the quantity of Computer Cases you would like to use: (up to 5)" << endl;
                        cin >> x4;
                        if(x4 > 5)
                        {
                            cout << "You cannot choose more than 5. Try again: " << endl;
                            cin >> x4;
                        }
                        if(inventory1.getNumComputerCases() >= x4)
                        {
                           inventory1.modifyNumComputerCases(-x4);
                           inventory1.modifyNumComputerParts(-x4);
                            num_parts +=x4;
                            repair(num_parts, computer1);
                            return; 
                        }
                        else
                        {
                            cout << "You do not have enough computer cases. Try again." << endl;
                            break;
                        }
                        break;
                        
                    }

                    case 5:
                    {
                        int x5 = 0;
                        cout << "Enter the quantity of Internet Cards you would like to use: (up to 5)" << endl;
                        cin >> x5;
                        if(x5 > 5)
                        {
                            cout << "You cannot choose more than 5. Try again: " << endl;
                            cin >> x5;
                        }
                        if(inventory1.getNumInternetCards() >= x5)
                        {
                            inventory1.modifyNumInternetCards(-x5);
                            inventory1.modifyNumComputerParts(-x5);
                            num_parts +=x5;
                            repair(num_parts, computer1);
                            return;
                        }
                        else
                        {
                            cout << "You do not have enough internet cards. Try again. " << endl;
                            break;
                        }
                        break;
                        
                    }

                    case 6:
                    {
                        int x6 = 0;
                        cout << "Enter the quantity of Keyboards and Mouses you would like to use: (up to 5)" << endl;
                        cin >> x6;
                        if(x6 > 5)
                        {
                            cout << "You cannot choose more than 5. Try again: " << endl;
                            cin >> x6;
                        }
                        if(inventory1.getNumKeyboardsAndMouses() >= x6)
                        {
                            inventory1.modifyNumCpu(-x6);
                            inventory1.modifyNumComputerParts(-x6);
                            num_parts +=x6;
                            repair(num_parts, computer1);
                            return;
                        }
                        else
                        {
                            cout << "You do not have enough keyboards and mouses. Try again." << endl;
                            break;
                        }
                        break;
                        
                    }
                    case 7:
                    {
                        return;
                    }
                    default:
                    {
                        cout << "Your input was incorrect. Please enter numerical option 1-7" << endl;
                        return;
                    }
                }
            } while (number != 7);
    }
    else if(computer1.getMaintenanceLevel() >= 100) // computer doesn't need to be repaired
    {
        cout << "Computer's maintenance level is greater than or equal to 100. You cannot repair it yet" << endl;
    }
    }
    
}
void generalMisfortune(Player&player1, Inventory&inventory1, Computer&computer1)
{

    srand(time(NULL));
    if(rand()%100 < 30)
    {
        int random = rand()%3 +1;
        if(random == 1)
        {
            // cout << "Num computer parts: " << inventory1.getNumComputerParts() << endl;;
            cout << "OH NO! Your team was robbed by Carmen’s dastardly hackers" << endl;
            cout << "You've lost one random computer part" << endl;
            cout << endl;
            // loses a randomly chosen computer part
            loseRandomComputerPart(inventory1);
        }
        else if (random == 2)
        {
            cout << "OH NO! Your computer was damaged!" << endl;
            cout << "Your maintenance level has been decreased by 10" << endl;
            cout << endl;
            computer1.modifyMaintenanceLevel(-10);
        }
        else if(random == 3)
        {
            cout << "OH NO! Why won’t my code work!!!!" << endl;
            cout << "Your frustration level was increased by 10." << endl;
            cout << endl;
            player1.modifyFrustrationLevel(10);

        }
    }
}
void BestBuy(Player&player1, Inventory&inventory1, Map&map1, int&room_number, int&total_cost)
{
    if(map1.isBestBuyLocation())
    {
        cout << "You are now in Best Buy" << endl;
        cout << endl;
        if(room_number == 1)
        {
            cout << "You have 200 dogecoins, 1 computer and 1 VPN. You will need to spend the rest of your money on the following items: " << endl;
            cout << "- COMPUTER PARTS. If your computer breaks, you need 5 computer parts to make a new one." << endl;
            cout << "- ANTIVIRUS SOFTWARE. If your computer is infected with a virus, use the antivirus software to get rid of it. " << endl;
            cout << "- VIRTUAL PRIVATE NETWORK (VPN). The more VPNs you havethe harder it is for a hacker to infect your computer with a  virus." << endl;
            cout << "- INTERNET PROVIDER. The better the internet provider, the more reliable your hacking will be. " << endl;
            cout << "You can spend all of your money here before you start your journey, or you can save some to spend on a different electronics site along the way. " << endl;
            cout << "But beware, some of the websites online are shady, and they won’t always give you a fair price... " << endl;
            cout << endl;
        }
        // using price coefficients since prices increase as the user progresses
        double price_coefficient = 0;
        if(room_number == 1)
        {
            price_coefficient =1;
        }
        else if(room_number == 2)
        {
            price_coefficient =1.1;
        }
        else if(room_number == 3)
        {
            price_coefficient = 1.2;
        }
        else if(room_number == 4)
        {
            price_coefficient = 1.25;
        }
        else if(room_number == 5)
        {
            price_coefficient = 1.3;
        }
        int choice = 0;
        cout << "What would you like to buy? " << endl;
        cout << "=====Menu====" << endl;
        cout << "1. Computer parts" << endl;
        cout << "2. Antivirus software" << endl;
        cout << "3. Virtual Private Network (VPN)" << endl;
        cout << "4. Internet Provider" << endl;
        cout << "5. Quit" << endl;
        cin >> choice;
        double antivirus_price = price_coefficient * 10;
        double vpn_price = price_coefficient * 20;
        double level2_price = price_coefficient * 10;
        double level3_price = price_coefficient * 25;
        double level4_price = price_coefficient * 40;
        double level5_price = price_coefficient * 50;
        do
        {
            switch(choice)
            {
                case 1: //buying computer parts
                {
                    if(player1.getDogecoinAmount() >= 5) // checking if the user has enough money to buy the cheapest item
                    {
                        computerParts(player1, inventory1, total_cost, room_number);
                        
                    }
                    else
                    {
                        cout << "You do not have enough money." << endl;
                        
                    }
                    cout << "Current total cost: " << total_cost << endl;
                    break;
                }
                case 2: // buying antiirus software
                {
                    int num =0;
                    cout << "How many antivirus USB sticks would you like to purchase?" << endl;
                    cin >> num;
                    if(player1.getDogecoinAmount() >= num * antivirus_price) // checking if the user has enough money
                    {
                        player1.num_antivirus_USB += num; // modifying num antivirus
                        player1.modifyDogecoinAmount(-1*antivirus_price*num); // modifying user balance
                        total_cost += antivirus_price*num; // modifying total cost
                        
                    }
                    else
                    {
                        cout << "You do not have enough money." << endl;
                       
                    }
                    cout << "Current total cost: " << total_cost << endl;
                    break;
                }
                case 3: // buying VPNs
                {
                    int n = 0;
                    cout << "How many VPNs would you like to purchase?" << endl;
                    cin >> n;
                    if(n <=2) // the user cannot buy more than 2 VPNs
                    {
                        if(player1.getDogecoinAmount() >= n * vpn_price) // checking if the user has enough money
                        {
                            player1.modifyVpnAmount(n); // modifying VPN amount
                            player1.modifyDogecoinAmount(-1*vpn_price*n); // modifying user balance
                            total_cost +=vpn_price*n; // modifying total cost
                        }
                        else
                        {
                            cout << "You do not have enough money." << endl;
                        }
                    
                    }
                    else
                    {
                        cout << "You cannot buy more than 2 VPNs. The increase in security maxes out at 2 VPNs." << endl;
                    }
                    cout << "Current total cost: " << total_cost << endl;
                    break;
                }
                case 4: // buying internet providers of different levels
                {
                    int level = 0;
                    cout << "What internet provider level would you like to buy?" << endl;
                    cin >> level;
                    if(level == 2)
                    {
                        if(player1.getDogecoinAmount() >= level2_price)
                        {
                            player1.modifyDogecoinAmount(-1*level2_price); // modifying user balance
                            player1.setInternetProviderLevel(2); // updating level
                            total_cost += level2_price; // modifying total cost
                            
                        }
                        else
                        {
                            cout << "You do not have enough money. You currently cannot buy an internet provider." << endl;
                            
                        }
                    }
                    
                    else if (level == 3)
                    {
                        if (player1.getDogecoinAmount() >=level3_price)
                        {
                            player1.setInternetProviderLevel(3); // updating level
                            player1.modifyDogecoinAmount(-1*level3_price); // modifying user balance
                            total_cost += level3_price; // modifying total cost
                            
                        }
                        else
                        {
                            cout << "You do not have enough money. Choose another level." << endl;
                        }
                        
                    }
                    else if (level == 4)
                    {
                        if(player1.getDogecoinAmount() >= level4_price)
                        {
                            player1.setInternetProviderLevel(4); // updating level
                            player1.modifyDogecoinAmount(-1*level4_price); // modifying user balance
                            total_cost += level4_price; // modifying total cost
                            
                        }
                        else
                        {
                            cout << "You do not have enough money. Choose another level." << endl;
                        }
                        
                    }
                    else if (level == 5)
                    {
                        if(player1.getDogecoinAmount() >= level5_price)
                        {
                            player1.setInternetProviderLevel(5); //updating level
                            player1.modifyDogecoinAmount(-1*level5_price); // modifying user balance
                            total_cost += level5_price; // modifying total cost
                            
                        }
                        else
                        {
                            cout << "You do not have enough money. Choose another level." << endl;
                        }
                        
                    }
                    
                    cout << "Current total cost: " << total_cost << endl;
                    break;
                }
                case 5:
                {
                    break;
                }
                default:
                {
                    cout << "Incorrect input. Try again. " << endl;
                    break;
                }
            }
            cout << "What would you like to buy? " << endl;
            cout << "=====Menu====" << endl;
            cout << "1. Computer parts" << endl;
            cout << "2. Antivirus software" << endl;
            cout << "3. Virtual Private Network (VPN)" << endl;
            cout << "4. Internet Provider" << endl;
            cout << "5. Quit" << endl;
            cin >> choice;
    
        } while (choice != 5);
        
    }
}
vector <vector<string>> ReadPuzzlesFile()
{
    // using a 2d vector to store puzzles from a file
    // 1st parameter - puzzle number, 2nd parameter- num of lines in the puzzle
    vector <vector<string>> puzzles;
    ifstream inFile;
    inFile.open("puzzles.txt");
    string line = "";
    // creating a temp vector to store lines
    vector <string> temp_vector;
    while(getline(inFile, line))
    {
        
        if(line == "---")
        {
            puzzles.push_back(temp_vector);
            temp_vector.clear();
        }
        else
        {
            temp_vector.push_back(line);
        }
    }
    inFile.close();

    return puzzles;
}
vector <vector<string>> ReadAnswersFile()
{
    // using a 2d vector to store answer from a file
    // 1st parameter - answer number, 2nd parameter- num of lines in the answer
    vector <vector<string>> answers;
    string line = "";
    ifstream inFile;
    inFile.open("answers.txt");
    vector <string> temp_vector; // using temp vector to store lines
    while(getline(inFile, line))
    {
        if(line == "---")
        {
            answers.push_back(temp_vector);
            temp_vector.clear();
        }
        else
        {
            temp_vector.push_back(line);
        }
    }
    inFile.close();
    return answers;
}
bool CompletePuzzle( int&num_puzzles_solved)
{
    bool result;
    cout << "Be ready to solve a puzzle!" << endl;
    cout << "===Hint===" << endl;
    cout << "For the debugging questions, there will only be one error!" << endl;
    cout << "Enter the line number of the errant line of code as a solution to each debugging puzzle." << endl;
    cout << "For the multiple choice questions, enter the letter that corresponds to the correct answer." << endl;
    cout << endl;
    vector <vector<string>> puzzles;
    // read from the puzzles.txt
    puzzles = ReadPuzzlesFile();
    for(int i=0; i < puzzles[num_puzzles_solved].size(); i++)
    {
        cout << puzzles[num_puzzles_solved][i] << endl;
    }
    cout << endl;
    string answer = "";
    cout << "Enter your answer: " << endl;
    cin >> answer;
    vector <vector<string>> answers;
    // read from answers.txt
    answers = ReadAnswersFile();
    if(answer == answers[num_puzzles_solved][0])
    {
        cout << "Congrats! You successfully solved the puzzle!" << endl;
        cout << endl;
        result = true;
    }
    else
    {
        cout << "Sorry! Your answer is wrong! Think better next time!" << endl;
        cout << endl;
        result = false;

    }
    num_puzzles_solved ++;
    return result;

}
string capitalize(string str)
{
    int len = str.length();
    for(int i=0; i < len; i++)
    {
        if(str[i]>= 'a' && str[i]<= 'z')
        {
            str[i] = str[i]-32; 
        }
        
    }
    return str;
}
void finalData(string&name, Player&player1, vector <string>&hacker_names)
{
    ofstream outFile;
    outFile.open("results.txt");
    if(outFile.is_open())
    {
        outFile << "Player's name: " << name << endl;
        outFile << "Dogecoin: " << player1.getDogecoinAmount() << endl;
        outFile << "Hackers defeated: " << endl;
        for (int i=0; i < hacker_names.size(); i++)
        {
            outFile << hacker_names[i] << endl;
        }
    }
    else
    {
        cout << "Could not open file" << endl;
    }
    outFile.close();

}
void roomActivity(Player&player1, Computer&computer1, Inventory&inventory1, Hacker&hacker1, Map&map1, int&room_number,vector <Hacker>&hackers, int&total_cost, int&num_puzzles_solved, int&num_hackers, vector<string>&hacker_names, string&name)
{
    StatusUpdate(computer1, player1, inventory1, hacker1);
    cout << endl;
    int y = 0;
    do
    {
        if(hacker1.getNumHackersDefeated() == num_hackers) // checking if the player has defeated all the hackers in th romm
        {
            if(room_number != 5) // moving to the next room
            {
                cout << "You are moving to room " << room_number +1 << endl;
                cout << endl;
            }
            else // winning the game
            {
                cout << "CONGRATS ON WINNING THE GAME!!!" << endl;
                finalData(name,player1, hacker_names);
            }
            return;
        }
        activityMenu();
        cout << "Choose one of the following activities: " << endl;
        cin >> y;
        player1.modifyDogecoinAmount(5); // gaining 5 coins each turn
        if(inventory1.getNumGpu() >0) // additional coins
        {
            player1.modifyDogecoinAmount(inventory1.getNumGpu() *5);
        }
        // when the computer is infected, maintenance level drops by 10*num_viruses after every action taken on the menu
        if(computer1.getNumViruses() >0)
        {
            computer1.modifyMaintenanceLevel(-10* computer1.getNumViruses());
        }
        switch(y)
        {
            case 1: // fighting a hacker
            {
                player1.modifyFrustrationLevel(2);
                cout << "You have chosen to fight a hacker! Are you ready to test your skills?" << endl;
                cout << endl;
                fightHacker(player1, computer1, inventory1, hacker1, map1,room_number, hackers, num_hackers, hacker_names);
                break;
            }
            case 2: // speaking to NPC
            {
                bool puzzle;
                int choice = 0;
                player1.modifyFrustrationLevel(2);
                cout << "You have chosen to speak to NPC(non-player character)" << endl;
                cout << "You have two option: " << endl;
                cout << "1. Solve their puzzle" << endl;
                cout << "2. Take your chances" << endl;
                cin >> choice;
                switch(choice)
                {
                    case 1: // complete a puzzle
                    {
                        puzzle =CompletePuzzle(num_puzzles_solved);
                        if(puzzle == true) // gains a random computer part if the puzzle was solved successfully
                        {
                            gainRandomComputerPart(inventory1);
                        }
                        break;
                    }

                    case 2:
                    {
                        srand(time(0));
                        if(rand() %100 < 33) // friend
                        {
                            cout << "NPC is your friend! You've gained a random computer part!" << endl;
                            cout << endl;
                            gainRandomComputerPart(inventory1);
                        }
                        else if(rand()%100 < 66) // neutral
                        {
                            cout << "NPC is neutral! Nothing happens." << endl;
                            cout << endl;
                        }
                        else // enemy
                        {
                            cout << "NPC is your enemy! You've lost a random computer part!" << endl;
                            cout << endl;
                            loseRandomComputerPart(inventory1);
                        }

                    }
                }

                break;
            }
            case 3: // repair your computer
            {
                player1.modifyFrustrationLevel(2);
                cout << "You have chosen to repair your computer!" << endl;
                cout << endl;
                repairComputer(computer1, inventory1, player1);
                break;
            }
            case 4: // use antivirus software
            {
                cout << "You have chosen to clear you computer from viruses using USB stick" << endl;
                cout << endl;
                player1.modifyFrustrationLevel(2);
                useAntivirus(player1, computer1);
                break;
            }
            case 5: // travel the server room
            {
                player1.modifyFrustrationLevel(2);
                cout << "You have chosen to travel the Server Room. You get 10 moves!" << endl;
                cout << endl;
                travelRoom(player1, inventory1, map1, computer1, hacker1);
                break;
            }
            case 6: // browse StackOverflown
            {
                int o = 0;
                bool rock_paper_scissors;
                player1.modifyFrustrationLevel(2);
                cout << "You've chosen to browse StackOverflown!" << endl;
                cout << "You have two options: " << endl;
                cout << "1. Solve a puzzle" << endl;
                cout << "2. Play Rock, Paper Scissors" << endl;
                cin >> o;
                switch(o)
                {
                    case 1: // complete puzzle
                    {
                        bool game;
                        game = CompletePuzzle(num_puzzles_solved);
                        if(game == true)
                        {
                            cout << "Your frustration level is reduced by 5!" << endl;
                            cout << endl;
                            player1.modifyFrustrationLevel(-5);
                        }
                        break;
                    }
                    case 2: // play rock paper scissors
                    {
                        rock_paper_scissors = rockPaperScissors();
                        if(rock_paper_scissors == true)
                        {
                            cout << "Your frustration level will be reduced by 5!" << endl;
                            cout << endl;
                            player1.modifyFrustrationLevel(-5);
                        }
                        break;
                    }
                }
                break;
            }
            case 7: // visit Bestbuy
            {
                if(map1.isBestBuyLocation())
                {
                    BestBuy(player1, inventory1, map1, room_number, total_cost);
                }
                else
                {
                    cout << "You are not in the spot with Bestbuy" << endl;
                    cout << endl;
                }
                break;
            }
            case 8:
            {
                // user chooses to end the game
                cout << "Looks like you lost to Carmen's hackers. Practice your skills and you will be luckier next time!" << endl;
                finalData(name,player1,hacker_names);
                exit(0);
            }
            
            default: // incorrect input
            {
                cout << "Your input was incorrect. Try again." << endl;
                break;
            }
        }
        generalMisfortune(player1, inventory1, computer1);
        if(hacker1.getProgressCarmen() >= 100)
        {
            cout << "OH NO! Carmen's progress level reached 100." << endl;
            cout << "Looks like you couldn't handle Carmen's hackers." << endl;
            finalData(name,player1, hacker_names);
            exit(0);
        } 
        if(player1.getFrustrationLevel() >= 100)
        {
            cout << "OH NO! You have rage quit!" << endl;
            cout << "Looks like you couldn’t handle Carmen’s hackers." << endl;
            finalData(name,player1, hacker_names);
            exit(0);
        }
        if(computer1.getMaintenanceLevel() < 0)
        {
            if(inventory1.getNumPremadeComputers() > 0)
            {
                inventory1.modifyNumPremadeComputers(-1);
                cout << "Looks like you have an extra computer. Even though you maintenance level is below 0, you are saved!" << endl;
                continue;
            }
            else
            {
                cout << "OH NO! Your maintenance level is below 0!" << endl;
                cout << "Looks like you couldn't handle Carmen's hackers!" << endl;
                finalData(name,player1, hacker_names);
                exit(0);
            }
        }
    } while (y != 8);
}
void spawnRandomHackers(Map&map1, int&num_hackers)
{
    
    srand(time(0));
    int row_h1 = 0;
    int col_h1 = 0;
    num_hackers = rand()%3 +1;
    for(int i=0; i <num_hackers; i++)
    {
        // placing hackers
        row_h1 = rand()%4;
        col_h1 = rand()%8;
        bool placed_hacker = map1.spawnHacker(row_h1, col_h1);
        if(placed_hacker == false) // if the hacker was not place successfully
        {
            i--;
        }
    }

}
void spawnRandomNPC(Map&map1, int&num_npc)
{
    srand(time(0));
    int row_n1 = 0;
    int col_n1 = 0;
    num_npc =rand()%3 +1;
    for(int i=0; i <num_npc; i++)
    {
        // placing NPCs
        row_n1 = rand()%4;
        col_n1 = rand()%8;
        bool placed_npc = map1.spawnNPC(row_n1, col_n1);
        if(placed_npc == false) // if NPC was not placed successfully
        {
            i--;
        }
    }
}
void spawnRandomBestbuy(Map&map1)
{
    int row_b1 = rand()%4;
    int col_b1 = rand()%8;
    bool placed_bestbuy = map1.spawnBestBuy(row_b1,col_b1);
}

int main()
{
    string name = "";
    Player player1 = Player();
    Hacker hacker1 = Hacker();
    vector <Hacker> hackers; 
    Computer computer1 = Computer();
    Inventory inventory1 = Inventory();
    Map map1 = Map();
    int room_number =0;
    int total_cost =0;
    int num_puzzles_solved = 0;
    int num_hackers = 0;
    int num_npc =0;
    vector <string> hacker_names;
    readHackers(player1, hacker1, hackers);
    cout << "Please enter your name: " << endl;
    getline(cin, name);
    cout << "Hi, " << name << endl;
    cout << endl;
    // first server room
    cout << "Welcome to Turing room!" << endl;
    cout << endl;
    room_number = 1;
    srand(time(NULL));
    map1.spawnBestBuy(0,0);
    map1.setPlayerColPosition(0);
    map1.setPlayerRowPosition(0);

    //random hackers
    spawnRandomHackers(map1, num_hackers);
    // random NPCs
    spawnRandomNPC(map1, num_npc);

    // initial BestBuy visit
    BestBuy(player1, inventory1, map1, room_number, total_cost);
    cout << endl;
    // presenting the user with activity menu
    roomActivity(player1,computer1,inventory1,hacker1,map1,room_number,hackers, total_cost, num_puzzles_solved, num_hackers, hacker_names, name);

    // server room 2
    hacker1.setNumHackersDefeated(0);
    map1.resetMap();
    num_hackers = 0;
    num_npc = 0;
    cout << "Welcome to Ellis room!" << endl;
    cout << endl;
    room_number = 2;
    // spawn random Bestbuy
    spawnRandomBestbuy(map1);
    // spawn random hackers
    spawnRandomHackers(map1, num_hackers);
    // spawn random NPCs
    spawnRandomNPC(map1, num_npc);
    cout << endl;

    roomActivity(player1,computer1,inventory1,hacker1,map1,room_number,hackers, total_cost, num_puzzles_solved, num_hackers, hacker_names, name);

    // server room 3
    hacker1.setNumHackersDefeated(0);
    map1.resetMap();
    num_hackers = 0;
    num_npc = 0;
    cout << "Welcome to Johnson room!" << endl;
    cout << endl;
    room_number = 3;
    // spawn random Bestbuy
    spawnRandomBestbuy(map1);
    // spawn random hackers
    spawnRandomHackers(map1, num_hackers);
    // spawn random NPCs
    spawnRandomNPC(map1, num_npc);
    cout << endl;

    roomActivity(player1,computer1,inventory1,hacker1,map1,room_number,hackers, total_cost, num_puzzles_solved, num_hackers, hacker_names, name);


    // server room 4 
    hacker1.setNumHackersDefeated(0);
    map1.resetMap();
    num_hackers = 0;
    num_npc = 0;
    cout << "Welcome to Hopper room!" << endl;
    cout << endl;
    room_number = 4;
    // spawn random Bestbuy
    spawnRandomBestbuy(map1);
    // spawn random hackers
    spawnRandomHackers(map1, num_hackers);
    // spawn random NPCs
    spawnRandomNPC(map1, num_npc);
    cout << endl;
    roomActivity(player1,computer1,inventory1,hacker1,map1,room_number,hackers, total_cost, num_puzzles_solved, num_hackers, hacker_names, name);

    // server room 5
    hacker1.setNumHackersDefeated(0);
    map1.resetMap();
    num_hackers = 0;
    num_npc = 0;
    cout << "Welcome to Moore room!" << endl;
    cout << endl;
    room_number = 5;
    // spawn random Bestbuy
    spawnRandomBestbuy(map1);
    // spawn random hackers
    spawnRandomHackers(map1, num_hackers);
    // spawn random NPCs
    spawnRandomNPC(map1, num_npc);
    cout << endl;
    roomActivity(player1,computer1,inventory1,hacker1,map1,room_number,hackers, total_cost, num_puzzles_solved, num_hackers, hacker_names, name);

    return 0;
}